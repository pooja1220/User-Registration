INSERT INTO user (id, username, password) VALUES (1, 'pooja' , '1pooja');
INSERT INTO user (id, username, password) VALUES (2, 'ram' , '2ram');
INSERT INTO user (id, username, password) VALUES (3, 'varun' , '3varun');
INSERT INTO user (id, username, password) VALUES (4, 'john' , '4john');
INSERT INTO user (id, username, password) VALUES (5, 'rohit' , '5rohit');