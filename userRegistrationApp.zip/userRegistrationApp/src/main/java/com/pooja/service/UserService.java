package com.pooja.service;

import com.user.model.User;

public interface UserService {
	void save(User user);

    User findByUsername(String username);
}
S